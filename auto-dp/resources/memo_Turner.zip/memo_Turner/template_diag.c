int compute_MAINNAME0(HashTable *hashTable,int V1, int V2, CONST_INT) {
    int MAINNAME0 = INT_VALUE_NAME;
    int value;

    int tab[]={MAINNAME0,V1,V2,CONST};
    int size = SIZE_ARRAY;

    if(V1<0 || V2<0 || V2>=MAX || V1>=MAX || V1>V2){
        return INT_MAX;
    }
    if (get(hashTable,tab,size,&value)){
        return value;
    }

    int min_value = INT_MAX;


    for(int tmp=max(V1INC1,BOUNDJADJJ);tmp<=V2;tmp++){
        if(evaluate(V1,tmp)){
            min_value=min(min_value,add(bp_score(V1,tmp),add(compute_MAINNAME1(hashTable,V1,tmp,CONST),MFEFree(tmp+1,V2))));
        }
    }

    insert(hashTable,tab,size,min_value);
    return min_value;
} 

int compute_MAINNAME1(HashTable *hashTable,int V1, int V2, CONST_INT) {
    int MAINNAME1 = -INT_VALUE_NAME;
    int value;

    int tab[]={MAINNAME1,V1,V2,CONST};
    int size = SIZE_ARRAY;

    if(V1<0 || V2<0 || V2>=MAX || V1>=MAX || V1>V2){
        return INT_MAX;
    }
    if (get(hashTable,tab,size,&value)){
        return value;
    }

    int min_value = compute_MAINNAME2(hashTable,V1,V2,CONST);
    
    for(int tmp1=V1INC1;tmp1<=min(V2INC2,BOUNDIADJI);tmp1++){
        for(int tmp2=max(BOUNDJADJJ,tmp1+NB_HELIX);tmp2<=V2INC2;tmp2++){
            if(evaluate(tmp1,tmp2) && tmp1-tmp2+1<=THETA){
                int tmp3=INTB(tmp1,tmp2,V1,V2);

                if(tmp3!=INT_MAX){
                    min_value=min(min_value,
                    add(compute_MAINNAME1(hashTable,tmp1,tmp2,CONST),tmp3));
                }
            }
        }    
    }
    insert(hashTable,tab,size,min_value);
    return min_value;
} 

int compute_MAINNAME2(HashTable *hashTable,int V1, int V2, CONST_INT) {
    int MAINNAME2 = INT_VALUE_NAME;
    int value;

    int tab[]={MAINNAME2,-1,V1,V2,CONST};
    int size = SIZE_ARRAY+1;

    if(V1<0 || V2<0 || V2>=MAX || V1>=MAX || V1>V2){
        return INT_MAX;
    }

    if (get(hashTable,tab,size,&value)){
        return value;
    }

    int min_value = INT_MAX;
    
    for(int tmp=V1;tmp<=min(V2INC2,BOUNDIADJI);tmp++){
CHILDREN_SUM
        min_value = min(min_value,add(CHILDREN_MAX,MFEFree(V1INC1,tmp)));
    }
    

    insert(hashTable,tab,size,min_value);
    return min_value;
}
