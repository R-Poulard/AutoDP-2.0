
int compute_CLIQUE1(HashTable *hashTable,int i, int i2, int j2, int j) {
    int CLIQUE=1;
    int value;
    int tab[] = {CLIQUE,i,i2,j2,j};
    int size= 5;

   if(i2>=j2 || i2<i || j2>j){
        return INT_MAX;
    }

    if (get(hashTable,tab,size,&value)) { 
        return value;
    }
    
    int min_value = INT_MAX;
    int tmp;
    if (j == j2 && i <= i2) { 
        min_value = min(min_value, MFEFree(i+1,i2)); 
    }
    for(int k=i+1;k<=i2;k++){
        for(int l=max(j2,k+1);l<=j-1;l++){
            if(evaluate(k,l) && l-k+1<=THETA && (k<i2 || l==j2)){
                tmp=INTB(k,l,i,j);
                if(tmp!=INT_MAX){
                    min_value = min(min_value,add(compute_CLIQUE1(hashTable,k,i2,j2,l),tmp));
                }
            }
        }
    }
    
    insert(hashTable,tab,size,min_value);
    return min_value;
}

int compute_CLIQUE0(HashTable *hashTable,int i, int i2, int j2, int j) {
    int CLIQUE2=-1;
    int value;
    int tab[] = {CLIQUE2,i,i2,j2,j};
    int size= 5;

   if(i2>=j2 || i2<i || j2>j){
        return INT_MAX;
    }

    if (get(hashTable,tab,size,&value)) {
        return value;
    }
    int min_value=INT_MAX;
    for(int l=j2; l<=j; l++){
        min_value=min(min_value,add(bp_score(i,l),add(compute_CLIQUE1(hashTable,i,i2,j2,l),MFEFree(l+1,j))));
    }

    insert(hashTable,tab,size,min_value);
    return min_value;
}