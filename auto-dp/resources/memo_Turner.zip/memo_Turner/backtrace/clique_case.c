
void backtrace_CLIQUE1(HashTable *hashTable,int score,int i, int i2, int j2, int j) {
    
   if(i2>=j2 || i2<i || j2>j){
        return ;
    }

    int tmp;
    if (j == j2 && i <= i2 && score==MFEFree(i+1,i2)) { 
        backtrace_MFEFree(score,i+1,i2);
    }
    for(int k=i+1;k<=i2;k++){
        for(int l=max(j2,k+1);l<=j-1;l++){
            if(evaluate(k,l) && l-k+1<=THETA && (k<i2 || l==j2)){
                tmp=INTB(k,l,i,j);
                if(tmp!=INT_MAX){
                    int tmp0=compute_CLIQUE1(hashTable,k,i2,j2,l);
                    if(score==add(tmp0,tmp)){
                        backtrace_CLIQUE1(hashTable,tmp0,k,i2,j2,l);
                        backtrace_INTB(tmp,k,l,i,j);                        
                        return;
                    }
                }
            }
        }
    }
    return;
}

void backtrace_CLIQUE0(HashTable *hashTable,int score, int i, int i2, int j2, int j) {

   if(i2>=j2 || i2<i || j2>j){
        return ;
    }

    for(int l=j2; l<=j; l++){
        int tmp0=compute_CLIQUE1(hashTable,i,i2,j2,l);
        int mfe=MFEFree(l+1,j);
        if(score==add(bp_score(i,l),add(tmp0,mfe))){
            backtrace_CLIQUE1(hashTable,tmp0,i,i2,j2,l);
            backtrace_MFEFree(mfe,l+1,j);
            structure[i]=bracket;
            structure[l]=bracket+32;
            return;
        }
    }

    return ;
}