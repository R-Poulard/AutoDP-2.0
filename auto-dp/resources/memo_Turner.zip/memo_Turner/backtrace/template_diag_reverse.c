void backtrace_MAINNAME0(HashTable *hashTable, int score, int V1, int V2, CONST_INT) {
    
    if(V1<0 || V2<0 || V2>=MAX || V1>=MAX || V1>V2){
        return;
    }
     
    for(int tmp=V2;tmp<=BOUNDJADJJ;tmp++){
        if(evaluate(V1,tmp)){
            int tmp0=compute_MAINNAME1(hashTable,V1,tmp,CONST);
            int mfe=MFEFree(tmp+1,V2);
            if(score==add(bp_score(V1,tmp),add(tmp0,mfe))){
                backtrace_MAINNAME1(hashTable,tmp0,V1,tmp,CONST);
                structure[V1]=bracket;
                structure[tmp]=bracket+32;
                backtrace_MFEFree(mfe,V2+1,tmp);
                return;
            }
        }
    }

} 

void backtrace_MAINNAME1(HashTable *hashTable, int score, int V1, int V2, CONST_INT) {
    
    if(V1<0 || V2<0 || V2>=MAX || V1>=MAX || V1>V2){
        return;
    }

    int tmp0=compute_MAINNAME2(hashTable,V1,V2,CONST);
    if(score==tmp0){
        backtrace_MAINNAME2(hashTable,tmp0,V1,V2,CONST);
        return;
    }

    for(int tmp1=BOUNDIADJI;tmp1<V1;tmp1++){
        for(int tmp2=V2+1;tmp2<=BOUNDJADJJ;tmp2++){
            if(evaluate(tmp1,tmp2) && tmp1-tmp2+1<=THETA){
                int tmp3=INTB(V1,V2,tmp1,tmp2);
                if(tmp3!=INT_MAX){
                    tmp0=compute_MAINNAME1(hashTable,tmp1,tmp2,CONST);
                    if(score==add(tmp0,tmp3)){
                        backtrace_MAINNAME1(hashTable,tmp0,tmp1,tmp2,CONST);
                        backtrace_INTB(tmp3,V1,V2,tmp1,tmp2);
                        return;
                    }
                }
            }
        }    
    }
    return;
} 

void backtrace_MAINNAME2(HashTable *hashTable, int score, int V1, int V2, CONST_INT) {
    
    if(V1<0 || V2<0 || V2>=MAX || V1>=MAX || V1>V2){
        return;
    }

    for(int tmp=BOUNDIADJI;tmp<=V1;tmp++){
CHILDREN_SUM
        int mfe=MFEFree(V1INC1,tmp);
        if(score==add(CHILDREN_MAX,mfe)){
            CHILDREN_BACKTRACE
            backtrace_MFEFree(mfe,tmp,V1-1);
            return;
        }
    }
    
    return ;
}
