float compute_MAINNAME(HashTable *hashTable,INT_INDICES) {
    // index_start
    int MAINNAME = INT_VALUE_NAME;
    float value;
    int tab[]={MAINNAME,INDICES};
    int size = SIZE_ARRAY;

    if (get(hashTable,tab,size,&value)){
        return value;
    }
    // index_end    
    float min_value = FLT_MAX;
    
FOR_LOOP_NEW_VARIABLES_OPEN
CONDITIONS
MFE_SUM
CHILDREN_SUM
  INDENTmin_value = min_float(min_value,add(CHILDREN_MAX,MFE_MAX));
FOR_LOOP_NEW_VARIABLES_CLOSE
    // index_start
    insert(hashTable,tab,size,min_value);
    // index_end
    return min_value;
}
