char * structure backtrace_MAINNAME()
