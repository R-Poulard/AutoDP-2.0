#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ViennaRNA/fold_compound.h>
#include <ViennaRNA/utils/basic.h>
#include <ViennaRNA/utils/strings.h>
#include <ViennaRNA/mfe.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <ctype.h>
#include <string.h>
#include <limits.h>

#include "ViennaRNA/utils/basic.h"
#include "ViennaRNA/utils/structures.h"
#include "ViennaRNA/params/default.h"
#include "ViennaRNA/datastructures/basic.h"
#include "ViennaRNA/fold_vars.h"
#include "ViennaRNA/params/basic.h"
#include "ViennaRNA/constraints/hard.h"
#include "ViennaRNA/constraints/soft.h"
#include "ViennaRNA/grammar.h"
#include "ViennaRNA/structured_domains.h"
#include "ViennaRNA/unstructured_domains.h"
#include "ViennaRNA/loops/all.h"
#include "ViennaRNA/alphabet.h"
#include "ViennaRNA/mfe.h"
#include "H.c"

bt_struct *bt;

int scoring(vrna_fold_compound_t *fc,
                                         int i,
                                         int j,
                                         void *data) {
    //printf("%d %d\n",i,j);
  pk_compound *pk=(pk_compound*)data;
  int tmp;
  Node* first;
  Node* last;
  if(get_A(pk,&first,&last,&tmp,i-1,j-1)==0){
    init_root_inter(pk,i-1,j-1);
    fold(pk);
    get_A(pk,&first,&last,&tmp,i-1,j-1);
  }
  //printf("got %d %d,%d\n",tmp,i,j);
  if(tmp==INF){
    return INF+1;
  }
  return tmp;
}

int scoring_f(vrna_fold_compound_t *fc,
                                         int i,
                                         int j,
                                         void *data) {
    //printf("%d %d\n",i,j);
  pk_compound *pk=(pk_compound*)data;
  int min=INF;
  int free_energy;
  Node* first;
  Node* last;
  int tmp;
  for(int tmpi=0;tmpi<j-1;tmpi++){
    if(get_A(pk,&first,&last,&tmp,tmpi,j-1)==0){
      init_root_inter(pk,tmpi,j-1);
      fold(pk);
      get_A(pk,&first,&last,&tmp,tmpi,j-1);
    }
    //printf("get A %d,%d = %d\n",i,j-1,tmp);
    free_energy=MFEFree(pk,0,tmpi-1);
    //printf("ICI %d,%d,%d\n",min,tmp,add(tmp,free_energy));
    if(min>add(tmp,free_energy)){
      //printf("on change donc min\n");
      min=add(tmp,free_energy);
    }
  }
  if(min==INF){
    return INF+1;
  }
  
  return min;
}

//requiered beceause i and j are forming the base pair
int scoring_c(vrna_fold_compound_t *fc,
                                         int i,
                                         int j,
                                         void *data) {
    //printf("%d %d\n",i,j);
  pk_compound *pk=(pk_compound*)data;
  int tmp;
  Node* first;
  Node* last;
  if(get_A(pk,&first,&last,&tmp,i,j-2)==0){
    init_root_inter(pk,i,j-2);
    fold(pk);
    get_A(pk,&first,&last,&tmp,i,j-2);
  }
  //printf("got %d %d,%d\n",tmp,i,j);
  if(tmp==INF){
    return INF+1;
  }
  return tmp;
}


int custom_BT_c(vrna_fold_compound_t *gc,unsigned int ui,unsigned int uj,vrna_bps_t bp_stack,vrna_bts_t bt_stack,void *data){
  pk_compound *pk=(pk_compound*)data;
  int tmp;
  Node* first;
  Node* last;
  bt->bt_stack=bt_stack;
  bt->bp_stack=bp_stack;
  int i=(int)ui;
  int j=(int)uj;
  //printf("i=%d,j=%d\n",i,j-2);
  //printf("%c,%c,%c,%c\n",pk->line[i],pk->line[i+1],pk->line[j-2],pk->line[j-1]);
  get_A(pk,&first,&last,&tmp,i,j-2);
  //printf("tmp=%d\n",tmp);
  return backtrace_on_interval(pk,bt,tmp,i,j-2);
  
}


int custom_BT(vrna_fold_compound_t *gc,unsigned int ui,unsigned int uj,vrna_bps_t bp_stack,vrna_bts_t bt_stack,void *data){
  pk_compound *pk=(pk_compound*)data;
  int tmp;
  Node* first;
  Node* last;
  bt->bt_stack=bt_stack;
  bt->bp_stack=bp_stack;
  int i=(int)ui;
  int j=(int)uj;
  get_A(pk,&first,&last,&tmp,i-1,j-1);
  return backtrace_on_interval(pk,bt,tmp,i-1,j-1);
  //printf("got %d %d,%d\n",tmp,i,j);
}


int custom_BT_f(vrna_fold_compound_t *gc,unsigned int ui,unsigned int uj,vrna_bps_t bp_stack,vrna_bts_t bt_stack,void *data){
  pk_compound *pk=(pk_compound*)data;
  int tmp;
  Node* first;
  Node* last;
  int min=INF;
  int min_free_energy=INF;
  int min_tmp=INF;
  int free_energy;

  int best_i=0;
  int j=(int) uj;

  for(int i=0;i<j-1;i++){
    get_A(pk,&first,&last,&tmp,i,j-1);
    free_energy=MFEFree(pk,0,i-1);
    if(min>add(tmp,free_energy)){
      min=add(tmp,free_energy);
      best_i=i;
      min_free_energy=free_energy;
      min_tmp=tmp;
    }
  }
  
  printf("min_value %d,%d,%d\n",best_i,j-1,min);
  bt->bt_stack=bt_stack;
  bt->bp_stack=bp_stack;
  int res1=backtrace_on_interval(pk,bt,min_tmp,best_i,j-1);
 
  int res2=backtrace_MFEFree(pk,bt,min_free_energy,0,best_i-1);
  //printf("got %d %d,%d\n",tmp,i,j);
  printf("BT_res %d->%d\n",min_tmp,res1);
  printf("BT_res %d->%d\n",min_free_energy,res2);

  return res1 && res2;
}

char * post_process_f(vrna_fold_compound_t *fc,vrna_bps_t bp_stack,void *data){
  bt_struct *bt=(bt_struct*)data;
  char * ss=vrna_db_from_bps(bp_stack,bt->MAX+1);
  for(int i=0;i<bt->MAX;i++){
    if(bt->structure[i]!='.'){
      ss[i]=bt->structure[i];
    }
  }
  return ss;
}

void free_aux(void * data){
  pk_compound *pk=(pk_compound*)data;
  free_pk(data);
}


int folding(const char* seq, const char* con){

    /* initialize random number generator */
    vrna_init_rand();
    /* Generate a random sequence of 50 nucleotides */
    vrna_fold_compound_t *fc = vrna_fold_compound(seq, NULL, VRNA_OPTION_DEFAULT);
    vrna_constraints_add(fc, con, VRNA_CONSTRAINT_DB_DEFAULT);
    pk_compound * pk=create_pk_compound(fc,seq,con);

    bt=create_bt_struct(NULL,pk->MAX);
    //displayMatrix(strlen(seq));
    /* allocate memory for MFE structure (length + 1) */
    char *structure = (char *)vrna_alloc(sizeof(char) * (strlen(seq) + 1));
    /* predict Minmum Free Energy and corresponding secondary structure */

    vrna_gr_add_aux_f(fc,scoring_f,custom_BT_f,pk,NULL,free_aux);
    vrna_gr_add_aux_c(fc,scoring_c,custom_BT_c,pk,NULL,NULL);
    vrna_gr_add_aux_m(fc,scoring,custom_BT,pk,NULL,NULL);
    vrna_gr_add_aux_m1(fc,scoring,custom_BT,pk,NULL,NULL);

    vrna_gr_set_serialize_bp(fc,post_process_f,bt,NULL,NULL);

    float mfe = vrna_mfe(fc, structure);
    int nb=0;
    printf("Score %6.2f ",mfe);

    for(int i=0;i<pk->MAX;i++){         
      if(bt->structure[i]>64){
        if(bt->structure[i]<91){
          nb+=bt->structure[i];
        }
        else{             
          nb-=(bt->structure[i]-32);
        }
      }
    }
    printf("(backtrack impurty= %d)\n",nb);
    printf("%s\n", structure);

    /* cleanup memory */

    vrna_fold_compound_free(fc);
    free_bt(bt);
    free(structure);
    return 1;
}


int vrna_folding(const char* seq, const char* con){

    /* initialize random number generator */
    vrna_init_rand();
    /* Generate a random sequence of 50 nucleotides */
    vrna_fold_compound_t *fc = vrna_fold_compound(seq, NULL, VRNA_OPTION_DEFAULT);
    vrna_constraints_add(fc, con, VRNA_CONSTRAINT_DB_DEFAULT);
    /* allocate memory for MFE structure (length + 1) */
    char *structure = (char *)vrna_alloc(sizeof(char) * (strlen(seq) + 1));
    /* predict Minmum Free Energy and corresponding secondary structure */

    float mfe = vrna_mfe(fc, structure);
    int nb=0;
    printf("Score %6.2f ",mfe);

    printf("(backtrack impurty= %d)\n",nb);
    printf("%s\n", structure);

    /* cleanup memory */

    vrna_fold_compound_free(fc);
    
    return 1;
}

int main(int argc, char ** argv) {
  printf("File name: %s\n",argv[1]);
  FILE * fp = fopen(argv[1], "r");
  if (fp == NULL) {
      perror("Error opening file");
      return EXIT_FAILURE;
  }
  int nb_tests=0;
  clock_t start_time, end_time;
  double total_time = 0.0;

  start_time = clock();
  while(true){
      int b_len=0;
      int len=0;
      char * line=NULL;
      //reading of the sequence
      len=getline(&line,&b_len, fp);
        
      if(len<=0){    
            free(line);
            printf("End of file, %d tested",nb_tests);
            break;
      }
      if(line[0]=='#'){
            printf("%s",line);
            free(line);
            continue;
      }

        int MAX=len;
      if(line[len-1]=='\n'){
        MAX=len-1;
        nb_tests+=1;
      }

        //secondary structure
      char *ss = NULL;
      len=getline(&ss,&b_len, fp);
      if (len != -1) {
            if (ss[len - 1] == '\n') {
                ss[len - 1] = '\0'; // Replace newline character with null terminator
                len--; // Decrement the length to exclude the removed '\n'
            }
      }
      else{ 
            free(line);
            free(ss);
            printf("No secondary structure found for test %d\n",nb_tests);
            exit(-1);
      }
      for(int i=0;i<len;i++){
        ss[i]='.';
      }
        //reading the score
        char * correct_score=NULL;
        len=getline(&correct_score,&b_len, fp);
        if (len != -1) {
            if (correct_score[len - 1] == '\n') {
                correct_score[len - 1] = '\0'; // Replace newline character with null terminator
                len--; // Decrement the length to exclude the removed '\n'
            }
            // Convert the line to an integer
            
        }
        else{
            free(line);
            free(correct_score);
            free(ss);
            printf("No integer found for test %d\n",nb_tests);
            exit(-1);
        }
        int number = atoi(correct_score);
        printf("Test: %d Size of the Sequence: %d ---", nb_tests,MAX);
        
        //elements used to record backtrack
        
        //Start of test
        clock_t test_start_time = clock();
        printf("%s\n",line);
        vrna_folding(line,ss);
        folding(line,ss);
        fflush(NULL);
        clock_t test_end_time = clock();

        double test_time = ((double)(test_end_time - test_start_time)) / CLOCKS_PER_SEC;
        total_time += test_time;
        //end of test
        free(line);
        free(ss);
        free(correct_score);
    }
    end_time = clock();
    double total_execution_time = ((double)(end_time - start_time)) / CLOCKS_PER_SEC;

    printf(" Total execution time: %.4f seconds", total_execution_time);
    printf("(mean %.4f seconds)\n", total_time / nb_tests);

    fclose(fp);
    return 0;
  }